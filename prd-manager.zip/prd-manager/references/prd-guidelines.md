# PRD Guidelines

This document provides guidance on creating and maintaining effective Product Requirements Documents (PRDs).

## Philosophy

PRDs are living documents that evolve with your understanding of the feature. They serve as:

1. **Confluence-style knowledge base** - Central reference for context, decisions, and rationale
2. **Planning workspace** - Space to ask questions, document research, and explore approaches
3. **Implementation roadmap** - Bridge between high-level vision and specific backlog tasks
4. **Historical record** - Document why decisions were made for future reference

## When to Create a PRD

Create a PRD when:

- Planning a new feature or system that will span multiple sessions
- Working on something complex enough to need research and exploration
- Building something that will impact multiple parts of the system
- You need a central reference document beyond just backlog tasks

Don't create a PRD for:

- Simple bug fixes or one-off changes
- Tasks that can be fully captured in a single backlog task
- Quick experiments or prototypes (though these may evolve into PRDs)

## Document Structure

### Required Sections

Every PRD should have at minimum:

- **Title & Metadata** - Name, status, dates, owner
- **Overview** - What is this and why does it matter?
- **Goals & Objectives** - What are we trying to achieve?
- **Acceptance Criteria** - What does "done" look like?

### Recommended Sections

Include these sections as appropriate:

- **Background & Context** - Why are we building this?
- **Open Questions** - What do we need to figure out?
- **Research Notes** - Document findings and explorations
- **Dependencies** - What does this depend on or impact?
- **Architecture & Design** - How will we build it?
- **Implementation Plan** - Links to backlog tasks
- **Risks & Mitigation** - What could go wrong?

### Optional Sections

Add these if they provide value:

- **Timeline & Milestones** - When will this be delivered?
- **User Stories** - Who benefits and how?
- **References** - Links to related docs, designs, or PRDs
- **Notes & Discussion** - Ongoing thoughts and meeting notes

## Writing Style

- **Be conversational** - Write for humans, not machines
- **Be specific** - Vague requirements lead to unclear implementations
- **Be flexible** - Update sections as your understanding evolves
- **Be honest** - Capture uncertainties in Open Questions, not as if they're decided

## Status Workflow

Track PRD maturity through status updates:

1. **Draft** - Early stage, lots of open questions, active exploration
2. **In Review** - Ready for feedback, most questions answered
3. **Ready for Implementation** - All questions resolved, ready to break into tasks
4. **In Progress** - Tasks created, implementation underway
5. **Completed** - Feature shipped, PRD serves as historical record

## Integration with Backlog

### Before Breaking Down Tasks

Ensure the PRD has:

- Clear goals and acceptance criteria
- Major open questions answered
- Architecture decisions documented
- Dependencies identified

### When Breaking Down Tasks

1. Create atomic, independent tasks in the backlog
2. Reference the PRD in each task description
3. Update the PRD's "Implementation Plan" section with task links
4. Keep the PRD as the single source of truth for context and decisions

### During Implementation

- Update "Notes & Discussion" with findings and decisions
- Check off acceptance criteria as they're met
- Document any scope changes or pivots
- Keep backlog tasks and PRD in sync

## Iterative Refinement Process

PRDs are meant to evolve across multiple sessions:

### Session 1: Initial Draft
- Capture the core idea and motivation
- List initial goals and questions
- Identify obvious dependencies
- Don't worry about completeness

### Sessions 2-N: Refinement
- Answer open questions through research
- Document findings in Research Notes
- Refine architecture and design decisions
- Add new questions as they arise
- Update acceptance criteria based on learnings

### Final Session: Ready for Implementation
- All critical questions answered
- Architecture decisions documented
- Acceptance criteria clear
- Break down into backlog tasks

## Common Pitfalls

**Over-planning** - Don't try to answer every question upfront. Some answers come during implementation.

**Under-documenting decisions** - Capture WHY you made decisions, not just WHAT you decided.

**Ignoring updates** - Keep PRDs current during implementation. They're living documents.

**Skipping research** - Use the Research Notes section to document explorations and learnings.

**Missing dependencies** - Always identify what this depends on and what depends on this.

## Example PRD Structures

### Simple Feature PRD

For straightforward features:

- Overview
- Goals & Objectives
- Open Questions
- Architecture & Design
- Acceptance Criteria
- Implementation Plan

### Complex System PRD

For large, multi-phase systems:

- Full template with all sections
- Detailed research notes
- Multiple design decision sections
- Phased timeline
- Comprehensive risk analysis

### Exploratory PRD

For early-stage research:

- Overview & Background
- Open Questions (extensive)
- Research Notes (grows over time)
- Goals evolve as research progresses
- Implementation Plan added later

## Tips for Effective PRDs

1. **Start small, grow organically** - Begin with core sections, add detail as needed
2. **Use checklists liberally** - Track progress on questions, criteria, tasks
3. **Cross-reference generously** - Link to related PRDs, code, documentation
4. **Update dates** - Show when the PRD was last touched
5. **Embrace uncertainty** - Open Questions section is your friend
6. **Document alternatives** - Note approaches you considered and why you didn't choose them
7. **Keep it accessible** - Write for your future self who forgot why you made decisions
