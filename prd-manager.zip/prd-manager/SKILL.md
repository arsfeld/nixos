---
name: prd-manager
description: Manage Product Requirements Documents (PRDs) as a Confluence-style knowledge base in code. Use this skill when users want to plan features across multiple sessions, document research and decisions, or say things like "Let's work on this PRD" or "Create a PRD for [feature]". The skill supports iterative refinement of requirements and breaking them down into backlog tasks when ready.
---

# PRD Manager

## Overview

Manage Product Requirements Documents (PRDs) as living, evolving specifications stored in `/docs/requirements/`. PRDs serve as a Confluence-style knowledge base that bridges high-level feature planning and implementation through backlog tasks.

## When to Use This Skill

Use this skill when:

- User says "Let's work on this PRD" or "Create a PRD for [feature]"
- Planning a feature that will span multiple sessions
- Working on complex features needing research, exploration, or design decisions
- User needs a central reference document beyond backlog tasks
- Breaking down a completed PRD into backlog tasks

## Core Workflow

### 1. Creating a New PRD

When starting a new feature or system:

1. **Determine the PRD filename** - Use kebab-case: `feature-name.md` (e.g., `observability-stack.md`, `user-authentication.md`)

2. **Create the PRD file** - Copy the template from `assets/prd-template.md` to `/docs/requirements/[feature-name].md`

3. **Initialize metadata** - Update:
   - Title with the feature/system name
   - Status to "Draft"
   - Created date to today's date
   - Owner to the user's name or "arosenfeld" if unknown

4. **Fill initial sections** - Work with the user to populate:
   - Overview (2-3 sentences about what and why)
   - Goals & Objectives (what we're trying to achieve)
   - Background & Context (current state and motivation)
   - Open Questions (unknowns to explore)

5. **Confirm with user** - Show the initial PRD and confirm it captures their vision

### 2. Iterating on an Existing PRD

PRDs evolve across multiple sessions. When iterating:

1. **Read the current PRD** - Load `/docs/requirements/[feature-name].md` to understand the current state

2. **Identify the session goal** - Ask what the user wants to work on:
   - Answering open questions?
   - Documenting research findings?
   - Refining architecture decisions?
   - Adding acceptance criteria?
   - Updating based on implementation learnings?

3. **Update relevant sections** - Common iteration patterns:

   **Answering Questions:**
   - Check off answered questions in "Open Questions"
   - Document findings in "Research Notes"
   - Add new questions that arise

   **Design Decisions:**
   - Update "Architecture & Design" section
   - Document WHY decisions were made, not just WHAT
   - Note alternatives considered

   **Refinement:**
   - Add specificity to goals and acceptance criteria
   - Identify dependencies as they become clear
   - Update risks and mitigation strategies

   **Implementation Updates:**
   - Add notes to "Notes & Discussion" with dated entries
   - Update status as PRD matures
   - Check off acceptance criteria as met

4. **Update metadata** - Always update "Last Updated" date when making changes

5. **Keep it conversational** - PRDs should be readable and useful, not bureaucratic

### 3. Breaking Down into Backlog Tasks

When a PRD is ready for implementation:

1. **Verify readiness** - Check that:
   - Critical open questions are answered
   - Architecture decisions are documented
   - Acceptance criteria are clear
   - Dependencies are identified

2. **Identify task breakdown** - Review the PRD and identify atomic, independent implementation tasks

3. **Create backlog tasks** - Use MCP backlog tools to create tasks:
   ```
   For each implementation task:
   - Create task with mcp__backlog__task_create
   - Include PRD reference in description: "Part of [Feature Name] (see /docs/requirements/feature-name.md)"
   - Set appropriate priority, labels, and status
   - Add acceptance criteria aligned with the PRD
   ```

4. **Link tasks to PRD** - Update the PRD's "Implementation Plan" section:
   - List all created tasks with task IDs
   - Organize by phase or component if applicable
   - Keep as checklist format for tracking

5. **Update PRD status** - Change status from "Ready for Implementation" to "In Progress"

Example task creation:

```
Task Title: Implement Prometheus metrics collector
Description: Set up Prometheus on storage host to collect metrics from all services.

Part of Observability Stack (see /docs/requirements/observability-stack.md)

Acceptance Criteria:
- Prometheus deployed as systemd service
- Service discovery configured for all local services
- Metrics retention set to 15 days
- Accessible via Tailscale

Priority: high
Labels: [infrastructure, observability]
```

### 4. Ongoing Maintenance During Implementation

As tasks are completed:

1. **Update implementation plan** - Check off completed tasks in the PRD
2. **Document learnings** - Add notes about challenges, pivots, or discoveries
3. **Keep acceptance criteria current** - Adjust if scope changes
4. **Update status** - Move to "Completed" when all tasks are done

## PRD Guidelines

For detailed guidance on writing effective PRDs, consult `references/prd-guidelines.md` when:

- Unsure what sections to include
- Questions about PRD structure or content
- Need examples of different PRD types
- Want to understand the philosophy and workflow

Key principles:

- **PRDs are living documents** - They evolve with understanding
- **Be specific and honest** - Capture uncertainties, not false certainties
- **Document WHY, not just WHAT** - Future you will forget the context
- **Keep them flexible** - Adapt structure to the feature's needs
- **Integrate with backlog** - PRDs provide context, tasks drive execution

## File Organization

```
/docs/requirements/
├── feature-a.md          # One PRD per feature or system
├── feature-b.md          # Use kebab-case naming
└── observability-stack.md # Example from user's workflow
```

## Integration with Backlog System

The PRD skill works alongside the backlog MCP tools:

- **PRDs** = High-level planning, context, decisions, research
- **Backlog tasks** = Atomic implementation units with clear deliverables
- **Link them** = Tasks reference PRDs for context, PRDs track tasks for progress

This separation keeps:
- PRDs focused on WHY and WHAT at a high level
- Tasks focused on HOW and WHEN at a detailed level
- Both systems lightweight and useful

## Example Trigger Phrases

- "Let's work on this PRD"
- "Create a PRD for the observability stack"
- "Update the authentication PRD with what we learned"
- "Break down the observability PRD into tasks"
- "Add research notes to the [feature] PRD"

## Quick Reference

**Create PRD:**
1. Copy `assets/prd-template.md` → `/docs/requirements/[name].md`
2. Fill metadata and initial sections
3. Start with Draft status

**Iterate PRD:**
1. Read current PRD
2. Update relevant sections
3. Update "Last Updated" date

**Break into tasks:**
1. Use `mcp__backlog__task_create` for each task
2. Reference PRD in task descriptions
3. Update PRD's Implementation Plan
4. Change PRD status to In Progress
