# [Feature/System Name]

**Status:** Draft | In Review | Ready for Implementation | In Progress | Completed
**Created:** YYYY-MM-DD
**Last Updated:** YYYY-MM-DD
**Owner:** [Your name or team]

## Overview

[Brief 2-3 sentence description of what this feature/system is and why it matters]

## Background & Context

[Why are we building this? What problem does it solve? What's the current state?]

## Goals & Objectives

- [ ] Primary goal 1
- [ ] Primary goal 2
- [ ] Secondary goal 1

## Open Questions

Questions that need answers before or during implementation:

- [ ] Question 1?
- [ ] Question 2?
- [ ] Question 3?

## Research Notes

Document research findings, spikes, and investigation results:

### [Research Topic 1]
- Finding 1
- Finding 2
- Decision: [What we learned and decided]

### [Research Topic 2]
- Finding 1
- Finding 2
- Decision: [What we learned and decided]

## Dependencies & Related Systems

- **Depends on:** [Other systems, features, or infrastructure this requires]
- **Related to:** [Other PRDs, features, or systems that connect to this]
- **Impacts:** [What systems or features will be affected by this]

## Architecture & Design

### High-Level Design

[Describe the overall architecture and approach]

### Key Design Decisions

1. **Decision 1:** [What we decided and why]
2. **Decision 2:** [What we decided and why]
3. **Decision 3:** [What we decided and why]

### Technology Stack

- Component 1: Technology choice
- Component 2: Technology choice
- Component 3: Technology choice

## Acceptance Criteria

What does "done" look like?

- [ ] Criterion 1
- [ ] Criterion 2
- [ ] Criterion 3
- [ ] Documentation updated
- [ ] Tests written and passing

## Implementation Plan

[Once broken down into tasks, reference the backlog tasks here]

**Related Backlog Tasks:**
- [ ] task-XXX: [Task title]
- [ ] task-XXX: [Task title]
- [ ] task-XXX: [Task title]

## Timeline & Milestones

- **Phase 1:** [Description] - [Target date]
- **Phase 2:** [Description] - [Target date]
- **Phase 3:** [Description] - [Target date]

## Risks & Mitigation

| Risk | Impact | Probability | Mitigation |
|------|---------|-------------|------------|
| Risk 1 | High/Med/Low | High/Med/Low | How we'll address it |
| Risk 2 | High/Med/Low | High/Med/Low | How we'll address it |

## References

- [Link to relevant documentation]
- [Link to related PRDs]
- [Link to design docs or diagrams]

## Notes & Discussion

[Use this section for ongoing notes, meeting summaries, ad-hoc thoughts during implementation]

### [Date] - [Topic]
- Note 1
- Note 2

### [Date] - [Topic]
- Note 1
- Note 2
